# Sweeper Game



**使用方法**



* **For MacOS**

  如果沒有pygame則先安裝pygame

  ```
  pip3 install pygame
  ```

  運行sweeper.py

  ```
  python3 ./sweeper.py
  ```

  

* **For Windows**

  如果沒有pygame則先安裝pygame

  ```
  pip install pygame
  ```

  運行sweeper.py

  直接雙擊maze.py或運行如下命令

  ```
  python sweeper.py
  ```

  

  