# Maze Game



**使用方法**



* **For MacOS**

  如果沒有pygame則先安裝pygame

  ```
  pip3 install pygame
  ```

  運行maze.py

  ```
  python3 ./maze.py
  ```

  

* **For Windows**

  如果沒有pygame則先安裝pygame

  ```
  pip install pygame
  ```

  運行maze.py

  直接雙擊maze.py或運行如下命令

  ```
  python maze.py
  ```

  

  