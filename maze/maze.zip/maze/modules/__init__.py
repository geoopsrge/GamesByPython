'''初始化'''
from .sprites import Hero
from .mazes import Block, RandomMaze
from .misc import showText, Button, Interface