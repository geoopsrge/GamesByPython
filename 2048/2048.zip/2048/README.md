# 2048 Game



**使用方法**



* **For MacOS**

  如果沒有pygame則先安裝pygame

  ```
  pip3 install pygame
  ```

  運行2048.py

  ```
  python3 ./2048.py
  ```

  

* **For Windows**

  如果沒有pygame則先安裝pygame

  ```
  pip install pygame
  ```

  運行2048.py

  直接雙擊2048t.py或運行如下命令

  ```
  python 2048.py
  ```

  

  