'''初始化'''
from .Game2048 import Game2048
from .endInterface import endInterface
from .utils import getColorByNumber, drawGameMatrix, drawScore, drawGameIntro