'''初始化'''
from .endGame import endGame
from .startGame import startGame