# Flappy Bird Game



**使用方法**



* **For MacOS**

  如果沒有pygame則先安裝pygame

  ```
  pip3 install pygame
  ```

  運行flapptbird.py

  ```
  python3 ./flapptbird.py
  ```

  

* **For Windows**

  如果沒有pygame則先安裝pygame

  ```
  pip install pygame
  ```

  運行flapptbird.py

  直接雙擊flapptbird.py或運行如下命令

  ```
  python flapptbird.py
  ```

  

  