# 24 Point Game



**使用方法**



* **For MacOS**

  如果沒有pygame則先安裝pygame

  ```
  pip3 install pygame
  ```

  運行24point.py

  ```
  python3 ./24point.py
  ```

  

* **For Windows**

  如果沒有pygame則先安裝pygame

  ```
  pip install pygame
  ```

  運行24point.py

  直接雙擊24point.py或運行如下命令

  ```
  python 24point.py
  ```

  

  